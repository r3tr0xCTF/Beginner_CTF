// Feature test macros MUST be at the very top before includes
#define _GNU_SOURCE
#define _POSIX_C_SOURCE 200809L

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <unistd.h>
#include <signal.h>
#include <time.h>
#include <sys/time.h>
#include <fcntl.h>
#include <sys/types.h>
#include <errno.h>
#include <stdbool.h>

// Conditional includes for ptrace (may not be available on all systems)
#ifdef __linux__
#include <sys/ptrace.h>
#include <sys/wait.h>
#endif

// ═══════════════════════════════════════════════════════
// ADVANCED OBFUSCATION LAYER
// ═══════════════════════════════════════════════════════

// Multi-layer encryption keys (hidden in plain sight)
#define KEY_FOUNDING 0xAA
#define KEY_ATTACK 0x8A  
#define KEY_CART 0x45
#define KEY_FEMALE 0x55
#define KEY_JAW 0x33
#define KEY_WARHAMMER 0x77

// FIX: Corrected encrypted answers
// COLOSSAL = First XOR with index, then XOR with KEY_FOUNDING, then subtract 3
unsigned char wall1_answer[] = {0xEC, 0xF9, 0xE7, 0xFB, 0xF8, 0xF9, 0xE8, 0xE2, 0x00}; // Fixed for "COLOSSAL"

// ARMORED = Reversed, XOR with KEY_CART, add index, XOR with KEY_FEMALE  
unsigned char wall2_answer[] = {0x52, 0x50, 0x4E, 0x58, 0x5F, 0x4D, 0x51, 0x00}; // Fixed for "ARMORED"

// BEAST = Each char encrypted differently based on position
unsigned char wall3_answer[] = {0xEB, 0x29, 0xBE, 0x17, 0xEE, 0x00}; // Fixed for "BEAST"

// Fake flags and decoy strings (red herrings)
char decoy1[] = {0xE9, 0x81, 0xC4, 0xD5, 0xC4, 0xE1, 0xC4, 0xCA, 0xD5, 0xC4, 0xE7, 0xE1, 0xC6, 0xD5, 0xC4, 0xEE, 0xE1, 0xEE, 0xCC, 0xDD, 0x00}; // CTF{FAKE_FLAG}
char decoy2[] = {0xE9, 0x81, 0xC4, 0xD5, 0xC6, 0xCB, 0xD8, 0xD5, 0xD8, 0xCB, 0xCB, 0xD5, 0xCA, 0xE1, 0xCC, 0xD1, 0xDD, 0x00}; // CTF{NOT_TOO_EASY}
char decoy3[] = {0x43, 0x4F, 0x4C, 0x4F, 0x53, 0x53, 0x55, 0x53, 0x00}; // COLOSSUS (wrong spelling)

// Real encrypted flag (multi-layer encrypted)
unsigned char real_flag_p1[] = {0xBF, 0xD5, 0x90, 0x81, 0xD5, 0xDB, 0x9E, 0x9E, 0x82, 0x94, 0x83}; // CTF{THE_RUM
unsigned char real_flag_p2[] = {0x97, 0x93, 0x9A, 0x92, 0x9C, 0xDB, 0x95, 0x90, 0xD6, 0xDB}; // BLING_HAS_
unsigned char real_flag_p3[] = {0x97, 0x9E, 0x9C, 0x86, 0x92, 0xDB, 0xF2, 0xF0, 0xF0, 0xF0}; // BEGUN_2000
unsigned char real_flag_p4[] = {0xDB, 0x84, 0x9E, 0x90, 0xD6, 0xDB, 0x90, 0x9C, 0x92, 0x89}; // _YEARS_AGO}

// Wall Rose encrypted message (double encrypted)
unsigned char rose_message[] = {
    0x11, 0x2D, 0x20, 0x65, 0x04, 0x37, 0x28, 0x2A, 0x37, 0x20, 0x21, 0x65,
    0x16, 0x28, 0x23, 0x36, 0x37, 0x65, 0x21, 0x37, 0x31, 0x24, 0x26, 0x26,
    0x65, 0x24, 0x29, 0x31, 0x3B, 0x25, 0x29, 0x65, 0x11, 0x28, 0x22, 0x21,
    0x65, 0x06, 0x2F, 0x3F, 0x37, 0x65, 0x34, 0x3E, 0x23, 0x3F, 0x65, 0x37,
    0x3F, 0x65, 0x29, 0x28, 0x3D, 0x24, 0x65, 0x29, 0x24, 0x21, 0x26, 0x2C,
    0x37, 0x31, 0x3E, 0x21, 0x26, 0x36, 0x65, 0x36, 0x2A, 0x3F, 0x29, 0x65,
    0x37, 0x3F, 0x2B, 0x36, 0x22, 0x65, 0x36, 0x31, 0x36, 0x20, 0x2D, 0x75,
    0x00
};

// Anti-debugging variables (obfuscated names)
static volatile int paths_coordinate = 0;
static volatile int coordinate_system = 0x13579BDF;
static volatile int eldian_memory = 0xCAFEBABE;
static clock_t subjects_of_ymir;
static volatile int rumbling_active = 0;

// Function pointer obfuscation
typedef int (*validator_func)(const char*);
typedef void (*challenge_func)(void);

// Function prototypes
void display_banner(void);
void wall_maria_challenge(void);
void wall_rose_challenge(void);
void wall_sheena_challenge(void);
void display_victory(void);
char* decrypt_complex(unsigned char* data, int len, int method);
int validate_answer(const char* input, unsigned char* encrypted, int method);
void init_anti_debug(void);
int check_integrity(void);
void signal_handler(int sig);
void obfuscated_sleep(int ms);
void fake_check_routine(void);

// Helper functions for obfuscation
static inline int rot_left(int value, int shift) {
    return ((value << shift) | (value >> (32 - shift)));
}

static inline int custom_hash(const char* str) {
    int hash = 0x811C9DC5;
    while (*str) {
        hash ^= *str++;
        hash *= 0x01000193;
    }
    return hash;
}

int main() {
    // Initialize anti-debugging
    init_anti_debug();
    subjects_of_ymir = clock();
    
    // Clear screen with ANSI escape codes
    printf("\033[2J\033[1;1H");
    
    // Integrity check 1
    if (!check_integrity()) {
        printf("🔒 Abnormal Eldian detected. Access denied.\n");
        exit(1);
    }
    
    // Fake check routine (decoy)
    fake_check_routine();
    
    display_banner();
    
    // Run challenges with integrity checks between each
    challenge_func challenges[] = {wall_maria_challenge, wall_rose_challenge, wall_sheena_challenge};
    
    for (int i = 0; i < 3; i++) {
        // FIX: Check integrity before calling challenge, but coordinate_system gets modified in wall_maria_challenge
        // Only check integrity on first iteration or reset the expected value
        if (i == 0 && coordinate_system != 0x13579BDF) {
            printf("⚡ Coordinate system corrupted!\n");
            exit(1);
        }
        
        challenges[i]();
        
        // FIX: Reset coordinate_system after wall_maria_challenge modifies it
        if (i == 0) {
            coordinate_system = 0x13579BDF; // Reset to expected value
        }
        
        // Obfuscated integrity check
        if ((eldian_memory ^ 0xDEADBEEF) == 0x142154B1) {
            printf("🚨 Memory manipulation detected!\n");
            exit(1);
        }
        
        obfuscated_sleep(100);
    }
    
    display_victory();
    return 0;
}

void init_anti_debug() {
    // Set up signal handlers
    signal(SIGTRAP, signal_handler);
    signal(SIGILL, signal_handler);
    signal(SIGSEGV, signal_handler);
    
#ifdef __linux__
    // Ptrace self-attach
    #ifdef PTRACE_TRACEME
    if (ptrace(PTRACE_TRACEME, 0, 1, 0) == -1) {
        // Already being traced
        printf("🛡️ Titan hardening detected!\n");
        exit(1);
    }
    #endif
    
    // Check /proc/self/status for TracerPid
    FILE* status = fopen("/proc/self/status", "r");
    if (status) {
        char line[256];
        while (fgets(line, sizeof(line), status)) {
            if (strncmp(line, "TracerPid:", 10) == 0) {
                int pid = atoi(line + 10);
                if (pid != 0) {
                    fclose(status);
                    printf("🔍 Survey Corps surveillance detected!\n");
                    exit(1);
                }
            }
        }
        fclose(status);
    }
#endif
    
    // Check for common debugger environment variables
    const char* suspicious_env[] = {"LINES", "COLUMNS", "_", "SHLVL", NULL};
    int suspicious_count = 0;
    for (int i = 0; suspicious_env[i]; i++) {
        if (getenv(suspicious_env[i])) suspicious_count++;
    }
    if (suspicious_count >= 4) {
        printf("🎯 Abnormal environment detected!\n");
        exit(1);
    }
    
    // Timing check for single-stepping
    struct timeval start, end;
    gettimeofday(&start, NULL);
    
    // Dummy operations
    volatile int dummy = 0;
    for (int i = 0; i < 100000; i++) {
        dummy = (dummy + i) ^ 0xDEADBEEF;
    }
    
    gettimeofday(&end, NULL);
    long microseconds = (end.tv_sec - start.tv_sec) * 1000000 + (end.tv_usec - start.tv_usec);
    
    if (microseconds > 50000) {
        printf("⏱️ Time anomaly in the Paths detected!\n");
        exit(1);
    }
    
    paths_coordinate = 1;
}

int check_integrity() {
    // Complex integrity check
    int check1 = (coordinate_system ^ 0xDEADBEEF) ^ 0xDEADBEEF;
    int check2 = rot_left(eldian_memory, 13) ^ 0x5A5A5A5A;
    
    return (check1 == 0x13579BDF) && (check2 == rot_left(0xCAFEBABE, 13) ^ 0x5A5A5A5A);
}

void display_banner() {
    // Build banner dynamically
    printf("═══════════════════════════════════════════════════════\n");
    printf("      SURVEY CORPS INTELLIGENCE SYSTEM v2.0\n");
    printf("═══════════════════════════════════════════════════════\n\n");
    
    printf("🏰 Three walls protect humanity's greatest secret.\n");
    printf("🔍 Breach each layer to uncover the truth about titans.\n");
    printf("⚔️  The fate of humanity rests in your hands, soldier!\n\n");
}

char* decrypt_complex(unsigned char* data, int len, int method) {
    static char buffer[256];
    memset(buffer, 0, sizeof(buffer)); // FIX: Initialize buffer
    
    switch(method) {
        case 1: // Wall Maria - XOR with index, XOR with key, subtract
            for (int i = 0; i < len && i < 255 && data[i] != 0; i++) { // FIX: Check for null terminator
                buffer[i] = ((data[i] ^ i) ^ KEY_FOUNDING) - 3;
            }
            break;
            
        case 2: // Wall Rose - Reverse, XOR, add index, XOR
            for (int i = 0; i < len && i < 255 && data[len-1-i] != 0; i++) { // FIX: Better bounds checking
                int rev_idx = len - 1 - i;
                buffer[i] = ((data[rev_idx] ^ KEY_FEMALE) - i) ^ KEY_CART;
            }
            break;
            
        case 3: // Wall Sheena - Position-based encryption
            for (int i = 0; i < len && i < 255 && data[i] != 0; i++) { // FIX: Check for null terminator
                if (i == 0) buffer[i] = data[i] ^ KEY_FOUNDING ^ 0x03;
                else if (i == 1) buffer[i] = data[i] ^ KEY_CART ^ 0x29;
                else if (i == 2) buffer[i] = data[i] ^ KEY_FEMALE ^ KEY_FOUNDING;
                else if (i == 3) buffer[i] = data[i] ^ KEY_WARHAMMER ^ KEY_JAW;
                else if (i == 4) buffer[i] = data[i] ^ KEY_FOUNDING ^ KEY_CART ^ KEY_FEMALE;
                else buffer[i] = data[i];
            }
            break;
            
        default:
            buffer[0] = '\0';
    }
    
    return buffer;
}

int validate_answer(const char* input, unsigned char* encrypted, int method) {
    // FIX: Calculate length properly (exclude null terminator)
    int len = 0;
    while (encrypted[len] != 0 && len < 255) len++;
    
    char* decrypted = decrypt_complex(encrypted, len, method);
    
    // FIX: Add debug output for testing
    #ifdef DEBUG
    printf("DEBUG: Input='%s', Decrypted='%s'\n", input, decrypted);
    #endif
    
    return (strcmp(input, decrypted) == 0);
}

void wall_maria_challenge() {
    char input[50];
    
    printf("═══ WALL MARIA - OUTER DEFENSES ═══\n\n");
    
    // FIX: Display the cryptic text directly
    printf("📜 wsykoa`yo`afasqwSq~`sW`u`alu`l\n\n");
    printf("💭 The gate was first breached by the tallest of titans...\n");
    printf("🔐 Enter the titan's name: ");
    
    fgets(input, sizeof(input), stdin);
    input[strcspn(input, "\n")] = 0;
    
    // Convert to uppercase
    for (int i = 0; input[i]; i++) {
        input[i] = toupper(input[i]);
    }
    
    // Validate answer
    if (validate_answer(input, wall1_answer, 1)) {
        printf("\n✅ Wall Maria has fallen! The outer defenses are breached.\n\n");
        printf("🎯 Hint: The next wall guards secrets with layered encryption.\n");
        printf("💡 Sometimes you must look backwards to move forward...\n\n");
        coordinate_system = rot_left(coordinate_system, 7);
        coordinate_system = rot_left(coordinate_system, 25); // Rotate back
    } else {
        printf("\n❌ Incorrect. The wall stands firm.\n");
        printf("💭 Think: 60 meters tall, no skin...\n");
        exit(1);
    }
}

void wall_rose_challenge() {
    char input[50];
    
    printf("═══ WALL ROSE - MIDDLE DEFENSES ═══\n\n");
    
    printf("🔒 Intercepted transmission (hex dump):\n");
    printf("📊 ");
    for (int i = 0; rose_message[i]; i++) {
        printf("%02X ", rose_message[i]);
        if ((i + 1) % 12 == 0 && rose_message[i+1]) printf("\n    ");
    }
    printf("\n\n");
    
    // Decrypt message for display (double XOR)
    char decrypted[100];
    memset(decrypted, 0, sizeof(decrypted));
    for (int i = 0; rose_message[i] && i < 99; i++) {
        decrypted[i] = (rose_message[i] ^ KEY_CART) ^ KEY_FEMALE;
    }
    
    printf("📋 Decrypted: \"%s\"\n\n", decrypted);
    printf("💭 Reiner's secret identity...\n");
    printf("🔐 Enter the titan's name: ");
    
    fgets(input, sizeof(input), stdin);
    input[strcspn(input, "\n")] = 0;
    
    for (int i = 0; input[i]; i++) {
        input[i] = toupper(input[i]);
    }
    
    if (validate_answer(input, wall2_answer, 2)) {
        printf("\n✅ Wall Rose has fallen! The middle defenses are breached.\n\n");
        printf("🎯 Hint: The final wall uses a substitution cipher.\n");
        printf("💡 Each titan name maps to a single letter...\n\n");
        eldian_memory ^= 0x12345678;
        eldian_memory ^= 0x12345678; // Restore
    } else {
        printf("\n❌ Incorrect. The wall remains intact.\n");
        printf("💭 Think: Impenetrable defense, blonde warrior...\n");
        exit(1);
    }
}

void wall_sheena_challenge() {
    char input[100];
    
    printf("═══ WALL SHEENA - INNER SANCTUARY ═══\n\n");
    
    printf("🏛️ Final encryption - Titan Cipher:\n\n");
    printf("📝 Cipher Table:\n");
    printf("   ATTACK → A    BRAUN → B\n");
    printf("   CART → C      FEMALE → F\n");
    printf("   EREN → E      FOUNDER → F\n");
    printf("   JAW → J       WARHAMMER → W\n\n");
    
    // Display encoded message
    printf("🔍 Encoded message: BLEACH EREN ATTACK CART EREN\n");
    //printf("📋 Decoded: B E A C E → BEACH → BEAST\n\n");
    
    printf("💭 The intelligent titan who can speak and throw...\n");
    printf("🔑 Enter the password: ");
    
    fgets(input, sizeof(input), stdin);
    input[strcspn(input, "\n")] = 0;
    
    for (int i = 0; input[i]; i++) {
        input[i] = toupper(input[i]);
    }
    
    if (validate_answer(input, wall3_answer, 3)) {
        printf("\n✅ WALL SHEENA BREACHED! All defenses have fallen!\n\n");
        rumbling_active = 1;
    } else {
        printf("\n❌ Incorrect. The inner sanctuary remains sealed.\n");
        printf("💭 Think: Zeke's titan form...\n");
        exit(1);
    }
}

void display_victory() {
    printf("═══════════════════════════════════════════════════════\n");
    printf("🎉 CONGRATULATIONS, SURVEY CORPS MEMBER! 🎉\n");
    printf("═══════════════════════════════════════════════════════\n\n");
    
    printf("🏆 You have successfully breached all three walls!\n");
    printf("🔓 The truth about the titans is finally revealed:\n\n");
    
    // Hidden flag using character array construction and XOR obfuscation
    char flag_parts[][12] = {
        {'D', 'S', 'G', '}', 'S', 'I', 'F', '`', 'Q', 'T', 'N', '\0'},  // CTF{THE_RU
        {'C', 'O', 'J', 'O', 'I', 'M', 'F', '`', 'I', 'B', '\0'},       // MBLING_HAS
        {'C', 'F', 'H', 'T', 'O', '`', '3', '1', '1', '1', '\0'},       // _BEGUN_200
        {'`', 'Z', 'F', 'B', 'Q', 'R', '`', 'B', 'H', 'P', '~', '\0'}   // 0_YEARS_AG
    };
    
    char final_flag[64] = {0};
    int pos = 0;
    
    // Decrypt each part with simple XOR
    for (int part = 0; part < 4; part++) {
        for (int i = 0; flag_parts[part][i] != '\0' && i < 11; i++) {
            char decoded;
            if (part == 0) {
                decoded = flag_parts[part][i] ^ 0x01;  // Simple XOR to hide from strings
            } else if (part == 1) {
                decoded = flag_parts[part][i] ^ 0x01;
            } else if (part == 2) {
                decoded = flag_parts[part][i] ^ 0x01;
            } else {
                decoded = flag_parts[part][i] ^ 0x01;
            }
            final_flag[pos++] = decoded;
        }
    }
    
    // Add the missing characters manually to complete the flag
    final_flag[11] = 'M';   // Complete "RUM" -> "RUMBLING"
    final_flag[12] = 'B';
    final_flag[13] = 'L';
    final_flag[14] = 'I';
    final_flag[15] = 'N';
    final_flag[16] = 'G';
    final_flag[21] = '_';   // Fix spacing
    final_flag[32] = '0';   // Complete "200" -> "2000"
    final_flag[42] = 'O';   // Complete "AG" -> "AGO}"
    final_flag[43] = '}';
    final_flag[44] = '\0';
    
    // Actually, let's use a simpler approach with stack-based string construction
    char hidden_flag[64];
    int idx = 0;
    
    // Build flag character by character to avoid strings detection
    hidden_flag[idx++] = 'C';
    hidden_flag[idx++] = 'T';
    hidden_flag[idx++] = 'F';
    hidden_flag[idx++] = '{';
    hidden_flag[idx++] = 'T';
    hidden_flag[idx++] = 'H';
    hidden_flag[idx++] = 'E';
    hidden_flag[idx++] = '_';
    hidden_flag[idx++] = 'R';
    hidden_flag[idx++] = 'U';
    hidden_flag[idx++] = 'M';
    hidden_flag[idx++] = 'B';
    hidden_flag[idx++] = 'L';
    hidden_flag[idx++] = 'I';
    hidden_flag[idx++] = 'N';
    hidden_flag[idx++] = 'G';
    hidden_flag[idx++] = '_';
    hidden_flag[idx++] = 'H';
    hidden_flag[idx++] = 'A';
    hidden_flag[idx++] = 'S';
    hidden_flag[idx++] = '_';
    hidden_flag[idx++] = 'B';
    hidden_flag[idx++] = 'E';
    hidden_flag[idx++] = 'G';
    hidden_flag[idx++] = 'U';
    hidden_flag[idx++] = 'N';
    hidden_flag[idx++] = '_';
    hidden_flag[idx++] = '2';
    hidden_flag[idx++] = '0';
    hidden_flag[idx++] = '0';
    hidden_flag[idx++] = '0';
    hidden_flag[idx++] = '_';
    hidden_flag[idx++] = 'Y';
    hidden_flag[idx++] = 'E';
    hidden_flag[idx++] = 'A';
    hidden_flag[idx++] = 'R';
    hidden_flag[idx++] = 'S';
    hidden_flag[idx++] = '_';
    hidden_flag[idx++] = 'A';
    hidden_flag[idx++] = 'G';
    hidden_flag[idx++] = 'O';
    hidden_flag[idx++] = '}';
    hidden_flag[idx] = '\0';
    
    printf("    🚩 FLAG: %s\n\n", hidden_flag);
    
    printf("📚 Skills demonstrated:\n");
    printf("   • String deobfuscation and analysis\n");
    printf("   • Multi-layer encryption breaking\n");
    printf("   • Anti-debugging bypass techniques\n");
    printf("   • Reverse engineering under pressure\n\n");
    
    printf("⚔️  The Rumbling has been activated! You are free!\n");
    printf("═══════════════════════════════════════════════════════\n");
}

void signal_handler(int sig) {
    if (sig == SIGTRAP) {
        printf("🪤 Breakpoint detected! Titan shifting prevented!\n");
        exit(1);
    } else if (sig == SIGILL) {
        printf("⚠️ Illegal instruction! Coordinate tampering detected!\n");
        exit(1);
    } else if (sig == SIGSEGV) {
        printf("💥 Memory violation! The Paths reject your presence!\n");
        exit(1);
    }
}

void obfuscated_sleep(int ms) {
    // Custom sleep to avoid obvious sleep calls
    clock_t start = clock();
    while ((clock() - start) * 1000 / CLOCKS_PER_SEC < ms) {
        // Busy wait with dummy operations
        volatile int dummy = 0;
        for (int i = 0; i < 1000; i++) {
            dummy = (dummy + i) & 0xFF;
        }
    }
}

void fake_check_routine() {
    // Decoy function with fake checks
    volatile int fake_check = 0x41414141;
    
    // Fake password check (never actually used)
    char fake_pw[] = {0x50, 0x41, 0x53, 0x53, 0x57, 0x4F, 0x52, 0x44, 0x00};
    
    // Dummy operations that look important
    for (int i = 0; i < 8; i++) {
        fake_check ^= (fake_pw[i] << (i * 4));
    }
    
    // Result is never checked, this is just a decoy
    if (fake_check == 0xDEADBEEF) {
        // This will never execute
        volatile int x = 1337;
        x = x * 2;
    }
    
    // More dummy operations
    for (int i = 0; i < 10; i++) {
        fake_check = rot_left(fake_check, 3);
    }
}

// Additional decoy functions (red herrings)
int check_fake_password(const char* input) {
    // This function is never called but exists to confuse analysis
    return custom_hash(input) == 0xDEADC0DE;
}

void unused_decrypt_routine() {
    // Another decoy function with fake encryption
    char fake_data[] = {0xFF, 0xEE, 0xDD, 0xCC, 0xBB, 0xAA, 0x00};
    for (int i = 0; i < 6; i++) {
        fake_data[i] ^= 0x42;
    }
}